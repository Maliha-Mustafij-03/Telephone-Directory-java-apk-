package com.ads.Election_Employee;

import android.os.Bundle;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ads.Election_Employee.model.Contact;
import com.ads.Election_Employee.viewmodel.ContactViewModel;

public class AddContactActivity extends AppCompatActivity {

    private ContactViewModel contactViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        // **
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_white_24dp);
    }

    private void addContactToDb() {
        EditText contactNameEditText = findViewById(R.id.editText1);
        EditText contactDesignationEditText = findViewById(R.id.editText2);
        EditText contactNumberEditText = findViewById(R.id.editText3);
        EditText contactEmailEditText = findViewById(R.id.edit);

        // **
        String contactName = contactNameEditText.getText().toString();
        String contactDesignation = contactDesignationEditText.getText().toString();
        String contactNumber = contactNumberEditText.getText().toString();
        String contactEmail = contactEmailEditText.getText().toString();
        // **
        Contact contact = new Contact();
        contact.setContactName(contactName);
        contact.setContactDesignation(contactDesignation);
        contact.setContactNumber(contactNumber);
        contact.setContactEmail(contactEmail);

        if (contactName.isEmpty() || contactDesignation.isEmpty() ||contactNumber.isEmpty()){
            Toast.makeText(this, "Please insert data in all required fields!", Toast.LENGTH_SHORT).show();
        }

         else {
            // **
            contactViewModel = new ViewModelProvider(AddContactActivity.this).get(ContactViewModel.class);
            contactViewModel.insert(contact);
            // **
            Toast.makeText(this, "Employee Information saved!", Toast.LENGTH_SHORT).show();
            onBackPressed();
        }

    }

    // ActionBar Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_contact_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_save) {
            // **
            addContactToDb();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
